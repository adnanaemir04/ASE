from django.contrib import admin
from .models import Enrollment

admin.site.register(Enrollment)
